export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    
    if (url.pathname === "/api/health") {
      return new Response(JSON.stringify({ ok: true, name: "me-devolve" }), { headers: { ...cors, "Content-Type": "application/json" } });
    }
    
    // Por enquanto sem D1, só pra build passar
    return new Response(JSON.stringify({ message: "Me Devolve API online. Adicione D1 depois." }), { headers: { ...cors, "Content-Type": "application/json" } });
  }
}
